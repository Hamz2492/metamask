// netlify/functions/visitors.js
const fs = require('fs');
const path = require('path');

let visitorsData = [];

// مسار ملف البيانات
const DATA_FILE = path.join(__dirname, 'visitors.json');

// تحميل البيانات عند البدء
if (fs.existsSync(DATA_FILE)) {
  visitorsData = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

exports.handler = async (event) => {
  const ip = event.headers['client-ip'] || event.headers['x-forwarded-for'];
  const userAgent = event.headers['user-agent'];
  const isBot = /bot|crawl|spider|facebook|twitter|curl|wget/i.test(userAgent);
  
  // تحديث أو إضافة زائر
  const existingIndex = visitorsData.findIndex(v => v.ip === ip);
  const now = new Date();
  
  if (existingIndex >= 0) {
    visitorsData[existingIndex].lastSeen = now;
    visitorsData[existingIndex].visits += 1;
  } else {
    visitorsData.push({
      ip,
      userAgent,
      isBot,
      firstSeen: now,
      lastSeen: now,
      visits: 1
    });
  }
  
  // حفظ البيانات
  fs.writeFileSync(DATA_FILE, JSON.stringify(visitorsData, null, 2));
  
  // حساب الإحصائيات
  const stats = {
    total: visitorsData.length,
    humans: visitorsData.filter(v => !v.isBot).length,
    bots: visitorsData.filter(v => v.isBot).length,
    live: visitorsData.filter(v => (now - new Date(v.lastSeen)) < 5*60*1000).length,
    visitors: visitorsData
      .sort((a, b) => new Date(b.lastSeen) - new Date(a.lastSeen))
      .slice(0, 50) // عرض آخر 50 زائر فقط
  };
  
  return {
    statusCode: 200,
    body: JSON.stringify(stats)
  };
};